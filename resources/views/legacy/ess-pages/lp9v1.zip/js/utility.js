var providerList ={
	"AK" : 
	[
		{"providerName" : "Alaska Electric Light & Power"},
		{"providerName" : "Chugach Electric Association"},
		{"providerName" : "Copper Valley Electric Association"},
		{"providerName" : "Golden Valley Electric Association"},
		{"providerName" : "Kodlak Electric Association"},
		{"providerName" : "Municipal Light & Power"},
		{"providerName" : "Other"}
	],
	"AL" : 
	[
		{"providerName" : "Alabama Municipal Electric Authority"},
		{"providerName" : "Alabama Power"},
		{"providerName" : "PowerSouth"},
		{"providerName" : "Tennessee Valley Authority"},
		{"providerName" : "Wiregrass Electric Cooperative"},
		{"providerName" : "Other"}
	],
	"AR" : 
	[
		{"providerName" : "Southwestern Electric Power Company"},
		{"providerName" : "Entergy Arkansas, Inc."},
		{"providerName" : "Other"}

	],
	"AZ" : 
	[
		{"providerName" : "Arizona Public Service"},
		{"providerName" : "Salt River Project"},
		{"providerName" : "Tucson Electric Power"},
		{"providerName" : "UniSource Energy Services"}
	],
	"CA" : 
	[
		{"providerName" : "Alameda Municipal Power"},
		{"providerName" : "Anaheim Public Utilities"},
		{"providerName" : "Azusa Light & Water"},
		{"providerName" : "Burbank Water & Power"},
		{"providerName" : "Direct Energy"},
		{"providerName" : "East Bay Municipal Utility District"},
		{"providerName" : "Glendale Public Service Department"},
		{"providerName" : "Gridley Municipal Utilities"},
		{"providerName" : "Healdsburg Municipal Electric Department"},
		{"providerName" : "Imperial Irrigation District"},
		{"providerName" : "Los Angeles Department of Water and Power"},
		{"providerName" : "Nevada Irrigation District"},
		{"providerName" : "Pacific Gas and Electric"},
		{"providerName" : "Pasadena Water & Power"},
		{"providerName" : "Pacific Power"},
		{"providerName" : "Riverside Public Utilities"},
		{"providerName" : "Sacramento Municipal Utility District"},
		{"providerName" : "San Diego Gas & Electric"},
		{"providerName" : "Santa Clara Electric Department"},
		{"providerName" : "Sierra-Pacific Power"},
		{"providerName" : "Southern California Edison"},
		{"providerName" : "Southern California Public Power Authority"},
		{"providerName" : "TID Water & Power - Turlock Irrigation District"},
		{"providerName" : "Other"}

	],
	"CO" : 
	[
		{"providerName" : "Public Service Company of Colorado"},
		{"providerName" : "Colorado Springs Utilities"},
		{"providerName" : "Platte River Power Authority"},
		{"providerName" : "United Power, Inc."},
		{"providerName" : "Other"}

	],
	"CT" : 
	[
		{"providerName" : "AVANGRID"},
		{"providerName" : "Direct Energy"},
		{"providerName" : "Eversource Energy"},
		{"providerName" : "Northeast Utilities"},
		{"providerName" : "Other"}

	],
	"DE" : 
	[
		{"providerName" : "Ambit Energy"},
		{"providerName" : "City of Dover Electric Department"},
		{"providerName" : "City of Milford Electric Department"},
		{"providerName" : "City of Newark Electric Department"},
		{"providerName" : "City of Seaford Electric Department"},
		{"providerName" : "Delaware Electric Cooperative"},
		{"providerName" : "Delaware Municipal Electric Corporation"},
		{"providerName" : "Delmarva Power"},
		{"providerName" : "Lewes Board of Public Works"},
		{"providerName" : "Municipal Services Commission of the City of New Castle"},
		{"providerName" : "Town of Clayton Electric Department"},
		{"providerName" : "Town of Middletown Electric Department"},
		{"providerName" : "Town of Smyrna Electric Department"},
		{"providerName" : "Direct Energy"},
		{"providerName" : "Other"}

	],
	"DC" : 
	[
		{"providerName" : "PEPCO"},
		{"providerName" : "Direct Energy"},
		{"providerName" : "Other"}
	],
	"FL" : 
	[
		{"providerName" : "Beaches Energy Services"},
		{"providerName" : "Central Florida Electric Cooperative"},
		{"providerName" : "Choctawhatchee Electric Cooperative"},
		{"providerName" : "City of Alachua Public Services Department"},
		{"providerName" : "City of Bartow Electric Department"},
		{"providerName" : "City of Blountstown Electric Department"},
		{"providerName" : "City of Bushnell Utilities Department"},
		{"providerName" : "City of Chattahoochee Electric Department"},
		{"providerName" : "City of Fort Meade Utilities Department"},
		{"providerName" : "City of Green Cove Springs Utilities Department"},
		{"providerName" : "City of Lake Worth Utilities Department"},
		{"providerName" : "City of Moore Haven Utilities Department"},
		{"providerName" : "City of Mount Dora Electric Utility"},
		{"providerName" : "City of New Smyrna Beach Utilities Commission"},
		{"providerName" : "City of Newberry Electric Utility"},
		{"providerName" : "City of Quincy Utilities Department"},
		{"providerName" : "City of Starke Utilities Department"},
		{"providerName" : "City of Tallahassee Utilities"},
		{"providerName" : "City of Vero Beach Electric Utilities"},
		{"providerName" : "City of Wachula Utilities"},
		{"providerName" : "City of Williston Utilities Department"},
		{"providerName" : "City of Winter Park Electric Utility Department"},
		{"providerName" : "Clay Electric Cooperative"},
		{"providerName" : "Clewiston Utilities"},
		{"providerName" : "Duke Energy Florida, a part of Duke Energy"},
		{"providerName" : "Escambia River Electric Cooperative"},
		{"providerName" : "Florida Keys Electric Cooperative"},
		{"providerName" : "Florida Municipal Power Agency"},
		{"providerName" : "Florida Power & Light, a part of NextEra Energy"},
		{"providerName" : "Florida Public Utilities, a part of Chesapeake Utilities"},
		{"providerName" : "Fort Pierce Utilities Authority"},
		{"providerName" : "Gainesville Regional Utilities"},
		{"providerName" : "Glades Electric Cooperative"},
		{"providerName" : "Gulf Coast Electric Cooperative"},
		{"providerName" : "Gulf Power Company, a part of NextEra Energy"},
		{"providerName" : "Homestead Public Services"},
		{"providerName" : "JEA"},
		{"providerName" : "Keys Energy Services"},
		{"providerName" : "Kissimmee Utility Authority"},
		{"providerName" : "Lakeland Electric"},
		{"providerName" : "Lake Worth Utilities"},
		{"providerName" : "Lee County Electric Cooperative"},
		{"providerName" : "Leesburg Electric Department"},
		{"providerName" : "Ocala Electric Utility"},
		{"providerName" : "Okefenoke Rural Electric Membership Corporation"},
		{"providerName" : "Orlando Utilities Commission"},
		{"providerName" : "Palm Peach"},
		{"providerName" : "Peace River Electric Cooperative"},
		{"providerName" : "Progress Energy Florida"},
		{"providerName" : "PowerSouth Energy Cooperative"},
		{"providerName" : "Reedy Creek Energy Services"},
		{"providerName" : "St. Cloud Utilities"},
		{"providerName" : "Seminole Electric Cooperative"},
		{"providerName" : "Sumter Electric Cooperative"},
		{"providerName" : "Suwannee Valley Electric Cooperative"},
		{"providerName" : "Talquin Electric Cooperative"},
		{"providerName" : "TECO Energy, a part of Emera"},
		{"providerName" : "Town of Havana Utilities"},
		{"providerName" : "Tri-County Electric Cooperative"},
		{"providerName" : "West Florida Electric Cooperative"},
		{"providerName" : "Withlacoochee River Electric Cooperative"},
		{"providerName" : "Other"}

	],
	"GA" : 
	[
		{"providerName" : "Georgia Power"},
		{"providerName" : "Municipal Electric Authority of Georgia (MEAG Power)"},
		{"providerName" : "Oglethorpe Power"},
		{"providerName" : "Tennessee Valley Authority"},
		{"providerName" : "Altamaha EMC"},
		{"providerName" : "Amicalola EMC"},
		{"providerName" : "Blue Ridge Mountain EMC"},
		{"providerName" : "Canoochee EMC"},
		{"providerName" : "Carroll EMC"},
		{"providerName" : "Central Georgia EMC"},
		{"providerName" : "Coastal Electric Cooperative"},
		{"providerName" : "Cobb EMC"},
		{"providerName" : "Colquitt EMC"},
		{"providerName" : "Coweta-Fayette EMC"},
		{"providerName" : "Diverse Power Inc."},
		{"providerName" : "Diverse Power Inc. - Pataula District"},
		{"providerName" : "Excelsior EMC"},
		{"providerName" : "Flint Energies"},
		{"providerName" : "Grady EMC"},
		{"providerName" : "GreyStone Power Corp."},
		{"providerName" : "Habersham EMC"},
		{"providerName" : "Hart EMC"},
		{"providerName" : "Irwin EMC"},
		{"providerName" : "Jackson EMC"},
		{"providerName" : "Jefferson Energy Cooperative"},
		{"providerName" : "Little Ocmulgee EMC"},
		{"providerName" : "Marietta Power"},
		{"providerName" : "Middle Georgia EMC"},
		{"providerName" : "Mitchell EMC"},
		{"providerName" : "North Georgia EMC"},
		{"providerName" : "Ocmulgee EMC"},
		{"providerName" : "Oconee EMC"},
		{"providerName" : "Okefenoke REMC"},
		{"providerName" : "Planters EMC"},
		{"providerName" : "Rayle EMC"},
		{"providerName" : "Satilla REMC"},
		{"providerName" : "Sawnee EMC"},
		{"providerName" : "Slash Pine EMC"},
		{"providerName" : "Snapping Shoals EMC"},
		{"providerName" : "Southern Rivers Energy"},
		{"providerName" : "Sumter EMC"},
		{"providerName" : "Three Notch EMC"},
		{"providerName" : "Tri-County EMC"},
		{"providerName" : "Tri-State EMC"},
		{"providerName" : "Upson EMC"},
		{"providerName" : "Walton EMC"},
		{"providerName" : "Washington EMC"},
		{"providerName" : "Direct Energy"},
		{"providerName" : "Other"}

	],
	"HI" : 
	[
		{"providerName" : "Hawaiian Electric Company (HECO)"},
		{"providerName" : "Hawaiian Electric Light Company (HELCO)"},
		{"providerName" : "Kauaʻi Island Utility Cooperative (KIUC)"},
		{"providerName" : "Maui Electric Company (MECO)"},
		{"providerName" : "Other"}

	],
	"ID" : 
	[
		{"providerName" : "Avista"},
		{"providerName" : "Clearwater Power"},
		{"providerName" : "IDACORP (Idaho Power)"},
		{"providerName" : "PacifiCorp (Rocky Mountain Power)"},
		{"providerName" : "Other"}

	],
	"IL" : 
	[
		{"providerName" : "Ambit Energy"},
		{"providerName" : "Ameren"},
		{"providerName" : "Champion Energy"},
		{"providerName" : "City Water, Light & Power (Springfield, Illinois)"},
		{"providerName" : "ComEd"},
		{"providerName" : "Direct Energy"},
		{"providerName" : "Other"}

	],
	"IN" : 
	[
		{"providerName" : "American Electric Power (Indiana Michigan Power)"},
		{"providerName" : "Cinergy Corporation"},
		{"providerName" : "Duke Energy"},
		{"providerName" : "Indiana Municipal Power Agency"},
		{"providerName" : "Indianapolis Power & Light"},
		{"providerName" : "NiSource"},
		{"providerName" : "Northern Indiana Public Service Company"},
		{"providerName" : "Vectren (Southern Indiana Gas & Electric Company)"},
		{"providerName" : "Other"}

	],
	"IA" : 
	[
		{"providerName" : "Interstate Power and Light Company"},
		{"providerName" : "MidAmerican Energy"},
		{"providerName" : "Other"}

	],
	"KS" : 
	[
		{"providerName" : "Kansas City Board of Public Utilities"},
		{"providerName" : "Kansas City Power and Light Company"},
		{"providerName" : "Westar Energy"},
		{"providerName" : "Other"}

	],
	"KY" : 
	[
		{"providerName" : "American Electric Power"},
		{"providerName" : "Cinergy Corporation"},
		{"providerName" : "Direct Energy"},
		{"providerName" : "Duke Energy"},
		{"providerName" : "Kentucky Utilities"},
		{"providerName" : "Louisville Gas & Electric"},
		{"providerName" : "Owensboro Municipal Utilities"},
		{"providerName" : "Tennessee Valley Authority"},
		{"providerName" : "Other"}

	],
	"LA" : 
	[
		{"providerName" : "CLECO"},
		{"providerName" : "Entergy"},
		{"providerName" : "SWEPCO"},
		{"providerName" : "Other"}

	],
	"ME" : 
	[
		{"providerName" : "AVANGRID (Central Maine Power)"},
		{"providerName" : "Direct Energy"},
		{"providerName" : "Emera (Bangor Hydro Electric)"},
		{"providerName" : "Other"}

	],
	"MD" : 
	[
		{"providerName" : "A&N Electric Cooperative"},
		{"providerName" : "Agway Energy Services"},
		{"providerName" : "Allegheny Electric Cooperative"},
		{"providerName" : "Ambit Energy"},
		{"providerName" : "Baltimore Gas and Electric"},
		{"providerName" : "Berlin Electric Utility Department"},
		{"providerName" : "Champion Energy"},
		{"providerName" : "Choptank Electric Cooperative"},
		{"providerName" : "Conectiv"},
		{"providerName" : "Delmarva Power"},
		{"providerName" : "Direct Energy"},
		{"providerName" : "Easton Utilities"},
		{"providerName" : "FirstEnergy (Potomac Edison)"},
		{"providerName" : "Hagerstown Light Department"},
		{"providerName" : "Just Energy"},
		{"providerName" : "Southern Maryland Electric Cooperative (SMECO)"},
		{"providerName" : "Town of Thurmont Municipal Light Company"},
		{"providerName" : "Town of Williamsport Utilities"},
		{"providerName" : "Other"}

	],
	"MA" : 
	[
		{"providerName" : "Ashburnham Municipal Light"},
		{"providerName" : "Berkshire Company (WMECO)"},
		{"providerName" : "Braintree Electric Light Department"},
		{"providerName" : "Boylston Electric Light Department"},
		{"providerName" : "Chester Municipal Electric Light"},
		{"providerName" : "Chicopee Electric Light Department"},
		{"providerName" : "Concord Municipal Light Plant"},
		{"providerName" : "Danvers Electric Department"},
		{"providerName" : "Eversource Energy (NSTAR, Western Massachusetts Electric)"},
		{"providerName" : "Georgetown Electric Department"},
		{"providerName" : "Gosnold Municipal Electric Plant"},
		{"providerName" : "Groton Electric Department"},
		{"providerName" : "Groveland Light Department"},
		{"providerName" : "Hingham Municipal Light Department"},
		{"providerName" : "Holden Municipal Light Department"},
		{"providerName" : "Holyoke Gas and Electric"},
		{"providerName" : "Hudson Light and Water Department"},
		{"providerName" : "Hull Electric Light Department"},
		{"providerName" : "Ipswich Electric Light Department"},
		{"providerName" : "Littleton Electric Light and Water Department"},
		{"providerName" : "Marblehead Municipal Light Department"},
		{"providerName" : "Mansfield Municipal Light Department"},
		{"providerName" : "Merrimac Light and Water Department"},
		{"providerName" : "Middleboro Municipal Gas and Electric Department"},
		{"providerName" : "Middleton Municipal Light Department"},
		{"providerName" : "National Grid (Massachusetts Electric, Nantucket Electric)"},
		{"providerName" : "North Attleboro Electric Department"},
		{"providerName" : "Northeast Utilities"},
		{"providerName" : "Norwood Electric Light Department"},
		{"providerName" : "NSTAR"},
		{"providerName" : "Paxton Municipal Light Department"},
		{"providerName" : "Peabody Municipal Light Plant"},
		{"providerName" : "Princeton Electric Light Department"},
		{"providerName" : "Reading Municipal Light Department"},
		{"providerName" : "Rowley Electric Light Department"},
		{"providerName" : "Russell Municipal Light Department"},
		{"providerName" : "Shrewsbury Electric Light Department"},
		{"providerName" : "South Hadley Electric Light Department"},
		{"providerName" : "Sterling Electric Light Department"},
		{"providerName" : "Taunton Municipal Light Plant"},
		{"providerName" : "Templeton Municipal Light Company"},
		{"providerName" : "Unitil Corporation"},
		{"providerName" : "Wakefield Municipal Gas and Light Department"},
		{"providerName" : "Wellesley Municipal Light Plant"},
		{"providerName" : "West Boylston Municipal Lighting"},
		{"providerName" : "Westfield Gas and Electric Department"},
		{"providerName" : "PTI Electric Department"},
		{"providerName" : "Direct Energy"},
		{"providerName" : "Other"}

	],
	"MI" : 
	[
		{"providerName" : "Alger Delta Electric Cooperative"},
		{"providerName" : "Alpena Power Company"},
		{"providerName" : "American Electric Power (Indiana Michigan Power)"},
		{"providerName" : "Cherryland Electric Cooperative"},
		{"providerName" : "Cloverland Electric Cooperative"},
		{"providerName" : "Consumers Energy"},
		{"providerName" : "DTE Energy (DTE Energy Electric Company)"},
		{"providerName" : "Great Lakes Energy Cooperative"},
		{"providerName" : "Holland Board of Public Works"},
		{"providerName" : "Homeworks Tri-County Electric Cooperative"},
		{"providerName" : "Lansing Board of Water & Light"},
		{"providerName" : "Lowell Light and Power"},
		{"providerName" : "Midwest Energy & Communications (Cooperative)"},
		{"providerName" : "Ontonagon County REA (Cooperative)"},
		{"providerName" : "Presque Isle Electric & Gas Cooperative"},
		{"providerName" : "Thumb Electric Cooperative"},
		{"providerName" : "Upper Peninsula Power Company"},
		{"providerName" : "We Energies"},
		{"providerName" : "Wyandotte Municipal Services"},
		{"providerName" : "Other"}

	],
	"MN" : 
	[
		{"providerName" : "Basin Electric Power Cooperative"},
		{"providerName" : "Dairyland Power Coop"},
		{"providerName" : "East River Electric Power Co-op"},
		{"providerName" : "Freeborn-Mower Co-op Services"},
		{"providerName" : "Great River Energy, and its 28 member cooperatives"},
		{"providerName" : "Hutchinson Utilities Commission"},
		{"providerName" : "Interstate Power and Light Company"},
		{"providerName" : "L&O Power Co-op"},
		{"providerName" : "Marshall Municipal Utilities"},
		{"providerName" : "Minnkota Power Cooperative, and its 11 member cooperatives"},
		{"providerName" : "Minnesota Power"},
		{"providerName" : "Missouri River Energy"},
		{"providerName" : "Northern States Power Company, a subsidiary of Xcel Energy"},
		{"providerName" : "People's Co-op Tri-County Electric"},
		{"providerName" : "Otter Tail Power Company"},
		{"providerName" : "Rochester Public Utilities Commission"},
		{"providerName" : "Southern Minnesota Municipal Power Agency"},
		{"providerName" : "Willmar Municipal Utilities"},
		{"providerName" : "Xcel Energy"},
		{"providerName" : "Other"}

	],
	"MS" : 
	[
		{"providerName" : "Entergy Mississippi"},
		{"providerName" : "Magnolia Electric Power"},
		{"providerName" : "Mississippi Power"},
		{"providerName" : "Cooperative Energy"},
		{"providerName" : "Tennessee Valley Authority"},
		{"providerName" : "Other"}

	],
	"MO" : 
	[
		{"providerName" : "Ameren"},
		{"providerName" : "Aquila"},
		{"providerName" : "City Utilities of Springfield"},
		{"providerName" : "Empire District Electric Company"},
		{"providerName" : "Independence Power and Light"},
		{"providerName" : "Kansas City Power and Light Company"},
		{"providerName" : "Other"}

	],
	"MT" : 
	[
		{"providerName" : "Central Montana Electric Power Cooperative"},
		{"providerName" : "Montana-Dakota Utilities (MDU)"},
		{"providerName" : "Montana Electric Cooperatives' Association"},
		{"providerName" : "Northwestern Energy"},
		{"providerName" : "Other"}

	],
	"NE" : 
	[
		{"providerName" : "Nebraska Public Power District"},
		{"providerName" : "Omaha Public Power District"},
		{"providerName" : "Lincoln Electric System"},
		{"providerName" : "Other"}

	],
	"NV" : 
	[
		{"providerName" : "NV Energy (Nevada Power)"},
		{"providerName" : "Sierra Pacific Power"},
		{"providerName" : "Other"}
	],
	"NH" : 
	[
		{"providerName" : "Eversource Energy"},
		{"providerName" : "Liberty Utilities"},
		{"providerName" : "New Hampshire Electric Cooperative"},
		{"providerName" : "Northeast Utilities"},
		{"providerName" : "National Grid"},
		{"providerName" : "Unitil Corporation"},
		{"providerName" : "Other"}

	],
	"NJ" : 
	[
		{"providerName" : "GANDU Electric,heavy electric"},
		{"providerName" : "Atlantic City Electric"},
		{"providerName" : "Borough of Madison Electric Utility"},
		{"providerName" : "Borough of Milltown Electric Department"},
		{"providerName" : "Borough of Park Ridge Electric Department"},
		{"providerName" : "Borough of Seaside Heights Electric Utility"},
		{"providerName" : "Borough of South River Electric Department"},
		{"providerName" : "Butler Power and Light"},
		{"providerName" : "Direct Energy"},
		{"providerName" : "FirstEnergy"},
		{"providerName" : "Lavallette Electric Department"},
		{"providerName" : "Northeast Utilities"},
		{"providerName" : "Pemberton Borough Electric Department"},
		{"providerName" : "Public Service Electric and Gas Company (PSE&G)"},
		{"providerName" : "Rockland Electric"},
		{"providerName" : "South Jersey Industries"},
		{"providerName" : "Sussex Rural Electric Cooperative"},
		{"providerName" : "Vineland Municipal Electric Utility"},
		{"providerName" : "Other"}

	],
	"NM" : 
	[
		{"providerName" : "El Paso Electric"},
		{"providerName" : "Public Service Company of New Mexico"},
		{"providerName" : "Southwestern Public Service Company"},
		{"providerName" : "Other"}

	],
	"NY" : 
	[
		{"providerName" : "Central Hudson Gas & Elec Corp"},
		{"providerName" : "Consolidated Edison Co-NY Inc"},
		{"providerName" : "Fishers Island Utility Co Inc"},
		{"providerName" : "Jamestown Board of Public Util"},
		{"providerName" : "Long Island Power Authority"},
		{"providerName" : "New York State Elec & Gas Corp"},
		{"providerName" : "Niagara Mohawk Power Corp."},
		{"providerName" : "Orange & Rockland Utils Inc"},
		{"providerName" : "Pennsylvania Electric Co"},
		{"providerName" : "Rochester Gas & Electric Corp"},
		{"providerName" : "Steuben Rural Elec Coop, Inc"},
		{"providerName" : "Village of Freeport - (NY)"},
		{"providerName" : "Village of Rockville Centre - (NY)"},
		{"providerName" : "Village of Rouses Point - (NY)"},
		{"providerName" : "Other"}

	],
	"NC" : 
	[
		{"providerName" : "Albemarle Electric Membership Corporation"},
		{"providerName" : "Blue Ridge Energy"},
		{"providerName" : "Brunswick Electric Membership Corporation"},
		{"providerName" : "Cape Hatteras Electric Cooperative"},
		{"providerName" : "Carteret-Craven Electric Cooperative"},
		{"providerName" : "Central Electric Membership Corporation"},
		{"providerName" : "City of Concord Electric Departmemt"},
		{"providerName" : "Dominion North Carolina Power"},
		{"providerName" : "Duke Energy"},
		{"providerName" : "Edgecombe-Martin County Electric Membership Corporation"},
		{"providerName" : "EnergyUnited"},
		{"providerName" : "Four County Electric Membership Corporation"},
		{"providerName" : "French Broad Electric Membership Corporation"},
		{"providerName" : "Halifax Electric Membership Corporation"},
		{"providerName" : "Haywood Electric Membership Corporation"},
		{"providerName" : "Jones-Onslow Electric Membership Corporation"},
		{"providerName" : "Lumbee River Electric Membership Corporation"},
		{"providerName" : "North Carolina Electric Membership Corporation"},
		{"providerName" : "Pee Dee Electric Membership Corporation"},
		{"providerName" : "Piedmont Electric Membership Corporation"},
		{"providerName" : "Pitt & Greene Electric Membership Corporation"},
		{"providerName" : "Randolph Electric Membership Corporation"},
		{"providerName" : "Roanoke Electric Cooperative"},
		{"providerName" : "Rutherford Electric Membership Corporation"},
		{"providerName" : "South River Electric Membership Corporation"},
		{"providerName" : "Surry-Yadkin Electric Membership Corporation"},
		{"providerName" : "Tennessee Valley Authority"},
		{"providerName" : "Tideland Electric Membership Corporation"},
		{"providerName" : "Tri-County Electric Membership Corporation"},
		{"providerName" : "Union Power Cooperative"},
		{"providerName" : "Wake Electric Membership Corporation"},
		{"providerName" : "Other"}
	],
	"ND" : 
	[
		{"providerName" : "Basin Electric Power Cooperative"},
		{"providerName" : "Central Power Electric Cooperative"},
		{"providerName" : "Montana Dakota Utilities (MDU)"},
		{"providerName" : "Minnkota Power Cooperative"},
		{"providerName" : "Northern States Power Company"},
		{"providerName" : "Otter Tail Power Company"},
		{"providerName" : "Upper Missouri Power Cooperative"},
		{"providerName" : "Xcel Energy"},
		{"providerName" : "Other"}

	],
	"OH" : 
	[
		{"providerName" : "American Electric Power"},
		{"providerName" : "Cinergy Corporation"},
		{"providerName" : "Cleveland Electric Illuminating Company"},
		{"providerName" : "Consolidated Electric Cooperative"},
		{"providerName" : "Dayton Power & Light"},
		{"providerName" : "Direct Energy"},
		{"providerName" : "Duke Energy"},
		{"providerName" : "FirstEnergy"},
		{"providerName" : "Ohio Edison"},
		{"providerName" : "South Central Power Company"},
		{"providerName" : "Toledo Edison"},
		{"providerName" : "Other"}

	],
	"OK" : 
	[
		{"providerName" : "East Central Electric Cooperative"},
		{"providerName" : "Oklahoma Gas & Electric"},
		{"providerName" : "Public Service Company of Oklahoma"},
		{"providerName" : "Western Farmers Electric Cooperative"},
		{"providerName" : "Other"}

	],
	"OR" : 
	[
		{"providerName" : "Columbia River Public Utility District"},
		{"providerName" : "Eugene Water & Electric Board (EWEB)"},
		{"providerName" : "IDACORP (Idaho Power)"},
		{"providerName" : "PacifiCorp (Pacific Power)"},
		{"providerName" : "Portland General Electric"},
		{"providerName" : "West Oregon Electric Cooperative"},
		{"providerName" : "Other"}

	],
	"PA" : 
	[
		{"providerName" : "Adams Electric Cooperative"},
		{"providerName" : "Allegheny Electric Cooperative"},
		{"providerName" : "Bedford Rural Electric Cooperative"},
		{"providerName" : "Borough of Ephrata Electric Division"},
		{"providerName" : "Borough of Hatfield Electric Utility"},
		{"providerName" : "Borough of Kutztown Electric Department"},
		{"providerName" : "Borough of Quakertown Electric Department"},
		{"providerName" : "Borough of Schuylkill Haven Utilities Department"},
		{"providerName" : "Central Electric Cooperative"},
		{"providerName" : "Citizen's Electric Company"},
		{"providerName" : "Claverack Rural Electric Cooperative"},
		{"providerName" : "Direct Energy"},
		{"providerName" : "Duquesne Light"},
		{"providerName" : "FirstEnergy (Met-Ed, Penelec, Penn Power, West Penn Power)"},
		{"providerName" : "Lansdale Electric"},
		{"providerName" : "New Enterprise Rural Electric Cooperative"},
		{"providerName" : "Northeast Utilities"},
		{"providerName" : "Northwestern Rural Electric Cooperative"},
		{"providerName" : "PECO, a subsidiary of Exelon"},
		{"providerName" : "Perkasie Borough Electric Department"},
		{"providerName" : "Pike County Light & Power"},
		{"providerName" : "PPL Electric Utilities"},
		{"providerName" : "REA Energy Cooperative"},
		{"providerName" : "Rural Valley Electric Co."},
		{"providerName" : "Somerset Rural Electric Cooperative"},
		{"providerName" : "Sullivan County Rural Electric Cooperative"},
		{"providerName" : "Tri-County Rural Electric Cooperative"},
		{"providerName" : "UGI Utilities"},
		{"providerName" : "United Electric Cooperative"},
		{"providerName" : "Valley Rural Electric Cooperative"},
		{"providerName" : "Warren Electric Cooperative"},
		{"providerName" : "Wellsboro Electric Company"},
		{"providerName" : "Other"}

	],
	"RI" : 
	[
		{"providerName" : "Direct Energy"},
		{"providerName" : "National Grid (Narragansett Electric)"},
		{"providerName" : "Northeast Utilities"},
		{"providerName" : "Pascoag Utility District"},
		{"providerName" : "Other"}

	],
	"SC" : 
	[
		{"providerName" : "Aiken Electric Co-Op"},
		{"providerName" : "Central Electric Power Cooperative, Inc."},
		{"providerName" : "Duke Energy"},
		{"providerName" : "Progress Energy Carolinas"},
		{"providerName" : "Santee Cooper"},
		{"providerName" : "South Carolina Electric & Gas Company"},
		{"providerName" : "Tri-County Electric Co-Op"},
		{"providerName" : "Other"}

	],
	"SD" : 
	[
		{"providerName" : "Black Hills Power"},
		{"providerName" : "East River Electric Cooperative"},
		{"providerName" : "MidAmerican Energy Company"},
		{"providerName" : "Montana-Dakota Utilities (MDU)"},
		{"providerName" : "Northern States Power Company"},
		{"providerName" : "Northwestern Energy"},
		{"providerName" : "Otter Tail Power Company"},
		{"providerName" : "Rushmore Eletric Cooperative"},
		{"providerName" : "Xcel Energy"},
		{"providerName" : "Other"}

	],
	"TN" : 
	[
		{"providerName" : "Citizens Utilities Board"},
		{"providerName" : "Electric Power Board"},
		{"providerName" : "Kingsport Power (Appalachian Power)"},
		{"providerName" : "Knoxville Utilities Board"},
		{"providerName" : "Lenoir City Utilities Board"},
		{"providerName" : "Memphis Light, Gas and Water"},
		{"providerName" : "Nashville Electric Service"},
		{"providerName" : "Tennessee Valley Authority"},
		{"providerName" : "Other"}
	],
	"TX" : 
	[
		
		{"providerName" : "American Electric Power"},
		{"providerName" : "Amigo Energy"},
		{"providerName" : "Austin Energy"},
		{"providerName" : "Bartlett Electric Cooperative"},
		{"providerName" : "Brazos Electric Power Cooperative"},
		{"providerName" : "CenterPoint Energy"},
		{"providerName" : "City of Bryan"},
		{"providerName" : "City of Greenville"},
		{"providerName" : "Comanche Electric Cooperative"},
		{"providerName" : "CoServ Electric"},
		{"providerName" : "Cosery Electric"},
		{"providerName" : "CPS Energy"},
		{"providerName" : "Denton Municipal Electric"},
		{"providerName" : "Direct Energy"},
		{"providerName" : "dPi Energy"},
		{"providerName" : "El Paso Electric"},
		{"providerName" : "Electric Database Publishing"},
		{"providerName" : "Entergy"},
		{"providerName" : "Entrust Energy"},
		{"providerName" : "Fort Belknap Electric Cooperative"},
		{"providerName" : "Garland Power & Light"},
		{"providerName" : "GDF SUEZ Energy Resources"},
		{"providerName" : "Golden Spread Electric Cooperative"},
		{"providerName" : "Hudson Energy"},
		{"providerName" : "Hamilton County Electric Cooperative"},
		{"providerName" : "Heart of Texas Electric Cooperative"},
		{"providerName" : "HILCO Electric Cooperative"},
		{"providerName" : "J-A-C Electric Cooperative"},
		{"providerName" : "Lower Colorado River Authority"},
		{"providerName" : "Luminant"},
		{"providerName" : "MidSouth Synergy"},
		{"providerName" : "Navarro County Electric Cooperative"},
		{"providerName" : "Navasota Valley Electric Cooperative"},
		{"providerName" : "Oncor Electric Delivery (Formerly TXU)"},
		{"providerName" : "Pedernales Electric Cooperative"},
		{"providerName" : "PenTex Energy"},
		{"providerName" : "Reliant Energy"},
		{"providerName" : "South Plains Electric Cooperative"},
		{"providerName" : "Southwestern Public Service Company, a subsidiary of Xcel Energy"},
		{"providerName" : "Texas Electric Service Company"},
		{"providerName" : "Texas New Mexico Power"},
		{"providerName" : "Tara Energy"},
		{"providerName" : "Tri-County Electric Cooperative"},
		{"providerName" : "TXU Energy"},
		{"providerName" : "United Cooperative Services"},
		{"providerName" : "Wise Electric Cooperative"},
		{"providerName" : "Other"}
	],
	"UT" : 
	[
		{"providerName" : "Intermountain Power Agency (IPA)"},
		{"providerName" : "PacifiCorp (Rocky Mountain Power)"},
		{"providerName" : "Other"}

	],
	"VT" : 
	[
		{"providerName" : "Burlington Electric Department"},
		{"providerName" : "Central Vermont Public Service"},
		{"providerName" : "Gaz Métro (Green Mountain Power)"},
		{"providerName" : "Vermont Electric Cooperative"},
		{"providerName" : "Washington Electric Cooperative"},
		{"providerName" : "Other"}

	],
	"VA" : 
	[
		{"providerName" : "A&N Electric Cooperative"},
		{"providerName" : "Appalachian Power"},
		{"providerName" : "BARC Electric Cooperative"},
		{"providerName" : "Community Electric Cooperative"},
		{"providerName" : "Craig-Botetourt Electric Cooperative"},
		{"providerName" : "Danville Utilities"},
		{"providerName" : "Dominion Virginia Power"},
		{"providerName" : "Mecklenberg Electric Cooperative"},
		{"providerName" : "Northern Neck Electric Cooperative"},
		{"providerName" : "Northern Virginia Electric Cooperative"},
		{"providerName" : "Old Dominion Electric Cooperative"},
		{"providerName" : "Prince George Electric Cooperative"},
		{"providerName" : "Rapahannock Electric Cooperative"},
		{"providerName" : "Shenandoah Valley Electric Cooperative"},
		{"providerName" : "Southside Electric Cooperative"},
		{"providerName" : "Other"}

	],
	"WA" : 
	[
		{"providerName" : "Avista Utilities"},
		{"providerName" : "Benton County Public Utility District"},
		{"providerName" : "Chelan County Public Utility District"},
		{"providerName" : "Clark Public Utilities"},
		{"providerName" : "Douglas County Public Utility District"},
		{"providerName" : "Franklin County Public Utility District"},
		{"providerName" : "Grant County Public Utility District"},
		{"providerName" : "Klickitat Public Utility District"},
		{"providerName" : "Mason County Public Utility District 3"},
		{"providerName" : "Orcas Power and Light Coop (OPALCO)"},
		{"providerName" : "PacifiCorp (Pacific Power)"},
		{"providerName" : "Peninsula Light Co"},
		{"providerName" : "Pend Oreille County Public Utility District"},
		{"providerName" : "Puget Sound Energy"},
		{"providerName" : "Seattle City Light"},
		{"providerName" : "Snohomish County Public Utility District"},
		{"providerName" : "Tacoma Power"},
		{"providerName" : "Tanner Electric Coop"},
		{"providerName" : "Other"}

	],
	"WV" : 
	[
		{"providerName" : "Allegheny Electric Cooperative (Allegheny Power)"},
		{"providerName" : "Appalachian Power"},
		{"providerName" : "FirstEnergy (Mon Power, Potomac Edison)"},
		{"providerName" : "Wheeling Electric Power (AEP Ohio)"},
		{"providerName" : "Other"}

	],
	"WI" : 
	[
		{"providerName" : "Dairyland Power Cooperative"},
		{"providerName" : "Madison Gas and Electric"},
		{"providerName" : "Northern States Power Company-Wisconsin"},
		{"providerName" : "We Energies"},
		{"providerName" : "Wisconsin Power and Light Company"},
		{"providerName" : "Wisconsin Public Service Corporation"},
		{"providerName" : "Xcel Energy"},
		{"providerName" : "Other"}
	],
	"WY" : 
	[
		{"providerName" : "Cheyenne Light, Fuel & Power"},
		{"providerName" : "Lower Valley Energy"},
		{"providerName" : "PacifiCorp"},
		{"providerName" : "Other"}
	]
	
};











